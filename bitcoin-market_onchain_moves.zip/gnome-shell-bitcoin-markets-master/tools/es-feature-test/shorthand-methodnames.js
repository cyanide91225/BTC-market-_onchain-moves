log(
  ({
    success() {
      return "shorthand method literal success";
    }
  }).success()
);
