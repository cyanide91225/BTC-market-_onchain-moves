log(
  ((success = "default arguments success") => success)()
);
