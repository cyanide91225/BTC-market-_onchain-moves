const success = "success";
log(`template literal ${success}`);
