log(
  (
    ({ success = true }) => `success=${success}`
  )()
);
