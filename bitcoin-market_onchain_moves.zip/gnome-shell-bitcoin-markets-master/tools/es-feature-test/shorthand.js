const success = 'shorthand syntax success';
log(({ success }).success);
