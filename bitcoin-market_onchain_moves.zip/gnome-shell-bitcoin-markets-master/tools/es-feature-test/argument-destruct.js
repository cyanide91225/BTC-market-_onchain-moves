log(
  (
    ({ success }) => `arg destructuring success=${success}`
  )({ success: true })
);
