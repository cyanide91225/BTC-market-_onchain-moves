module.exports = {
  require: 'ts-node/register',
  extension: ['ts'],
};
